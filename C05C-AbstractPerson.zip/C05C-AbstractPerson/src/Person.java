import java.util.Random;

public abstract class Person {

	public Random r;

	private static String myName;
	private static String occupation;
	
	public Person(String name, String occupation) {
		myName = name;
		this.occupation = occupation;
	}
	
	static void askName() {
		System.out.println("What is your name?");
	}
	
	static void giveName() {
		//Displays the person giving their name
		System.out.println("My name is " + myName);
	}
	
	public void whatIDo() {
	}
	
	abstract void askQuestion();
	
	abstract void answerQuestion();
	
	
	
}
