
public class Philosopher extends Person{

	String[] questionsArray = new String[3];
	String[] answersArray = new String[3];
	
	
	public Philosopher(String name, String occupation) {
		super(name, occupation);
		
		questionsArray[0] = "To be or not to be?";
		questionsArray[1] = "That?"; //That is the question.
		questionsArray[2] = "Why is the sky blue?";
		
		answersArray[0] = "To be!";
		answersArray[1] = "Is the question";
		answersArray[2] = "It reflects off your eyes";
	}
	
	public void askQuestion() {
		//Asks random questions
		System.out.println(questionsArray[r.nextInt(0, 2)]);
	}
	
	public void answerQuestion() {
		System.out.println(answersArray[r.nextInt(0, 2)]);
	}
	
	public void whatIDo() {
		System.out.println("Mostly I twidle my thumbs.");
	}
	
}
