
public class Detective {
private	String name;
private int badgeNumber;

public Detective(String name, int badgeNumber) {
	this.name = name;
	this.badgeNumber = badgeNumber;
}
public String toString() {
	return "Detective [name=" + name + ", badgeNumber=" + badgeNumber + "]";
}

}
