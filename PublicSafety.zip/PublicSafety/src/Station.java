import java.util.Scanner;

public class Station {
public static final int MAXDETECTIVES = 5;
Detective[] detectives = new Detective[MAXDETECTIVES];
String stationName;
Scanner s = new Scanner(System.in);

public Station(String stationName) {
	this.stationName = stationName;
}

public void printDetectives() {
	System.out.println("List of detectives in "+stationName);
	for(Detective d:detectives) {
		if(d!=null) {
		System.out.println(d);
		}
	}
	System.out.println();
}
public void addDetective(int badgeNum) {
	System.out.println("new hire for "+stationName);
	System.out.println("Enter the detectives name: ");
	String name = s.nextLine();
boolean isFull = true;
	for(int i = 0;i<MAXDETECTIVES; i++) {
		if(detectives[i]==null) {
			detectives[i] = new Detective(name, badgeNum);
			isFull = false;
			break;
		}
	}
	if(isFull) {
		System.out.println("Cant hire any more detectives for "+stationName);
	}
}

}
