import java.util.Scanner;

public class PublicSafety {
Station city;
Station university;
private int[] badgeNumbers = new int[10];

public PublicSafety(String university, String city) {
	this.city = new Station(city);
	this.university= new Station(university);
}

public void doHire(boolean station) {
	int badgeNum = 0;
//go through and find the first open 
	for(int i:badgeNumbers) {
		if(i==0) {
			badgeNum=i+1;
			badgeNumbers[i]=badgeNum;
		}
	}

	if(station) {
		city.addDetective(badgeNum);
	}
	else {
		university.addDetective(badgeNum);
	}
}
public void printDetectiveLists() {
	city.printDetectives();
	university.printDetectives();
}
}
