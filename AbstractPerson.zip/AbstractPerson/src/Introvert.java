//DONE
public class Introvert extends Person{
	
	public Introvert(String name, String occupation) {
		super(name, occupation);
	}
	
	public void askQuestion() {
		System.out.println("What is your favorite color?");
	}
	
	public void answerQuestion() {
		System.out.println("My favorite color is blue");
	}
}
