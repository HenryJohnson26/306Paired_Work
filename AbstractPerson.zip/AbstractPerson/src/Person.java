import java.util.Random;

public abstract class Person {

	public Random r = new Random();

	private String myName;
	private String occupation;
	
	public Person(String name, String occupation) {
		myName = name;
		this.occupation = occupation;
	}
	
	public void askName() {
		System.out.println("What is your name?");
	}
	
	public void giveName() {
		//Displays the person giving their name
		System.out.println("My name is " + myName);
	}
	
	public void whatIDo() {
		System.out.println("I am a "+occupation);
	}
	
	abstract void askQuestion();
	
	abstract void answerQuestion();
	
	
	
}
