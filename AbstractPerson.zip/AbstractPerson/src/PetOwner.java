//DONE
public class PetOwner extends Person {
	
	String petType;
	String petName;
	
	
	public PetOwner(String name, String occupation, String petType, String petName) {
		super(name, occupation);
		
		this.petType = petType;
		this.petName = petName;
		
	}
	
	
	public void askQuestion() {
		int randomInt = r.nextInt(0, 1);
		if (randomInt == 0) {
			System.out.println("Do you want to hear about my " + petType + "?");
		} 
		else {
			System.out.println("Do you want to hear about my " + petType + ", " + petName + "?");
		}
	}
	
	public void answerQuestion() {
		int randomInt = r.nextInt(0, 1);
		if (randomInt == 0) {
			System.out.println("I really like my pet " + petType);
		} 
		else {
			System.out.println("I really like my " + petType + ", " + petName);
		}
	}
	
	public void whatIDo() {
		super.whatIDo();
		System.out.println("I like to play with my " + petType);
	}
}
